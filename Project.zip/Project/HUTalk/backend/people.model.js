const mongoose = require('mongoose');
const PeopleSchema = mongoose.Schema(
    {
        name:{
            type: String,
            required: [true,"Name is necessary"]
        },
        studentID:{
            type: String,
            required: [true,"ID is necessary"]
        }
        ,class:{
            type:Number,
            required:[true,"Class year is necessary"]
        },
        username:{
            type:String,
            required:[true,"Username is necessary"]
        },
        password:{
            type:String,
            required:[true,"Password is necessary"]
        },
        img:{
            type:String,
            required:false
        }
    },
    {
        timestamps: true
    }
)
const People= mongoose.model("People",PeopleSchema);
module.exports= People;