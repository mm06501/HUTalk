const express=require('express');
const mongoose=require('mongoose');
const People=require('./models/people.model.js')
const app=express();

app.use(express.json());

app.get('/',(req,res)=>{
    res.send("Hello from Node API Server")
})



mongoose.connect("mongodb+srv://therealalitehsin:sGSfP8xGPlAlw1Qo@backenddb.ofldt.mongodb.net/?retryWrites=true&w=majority&appName=BackendDB")
.then(()=>{
    console.log("Connected to the database!")
    app.listen(3000,()=>{
        console.log('Server is running on port 3000')
    })
}).catch((e)=>{
    console.log(e)
    console.log("Connection failed!")
})
app.post("/api/people",async(req,res)=>{
    try{
        const person = await People.create(req.body);
        res.status(200).json(person);
    }catch(error){
        res.status(500).json({message:error.message})
    }
})

app.get("/api/people",async(req,res)=>{
    try{
        const people=await People.find({});
        res.status(200).json(people);
    }catch(error){
        res.status(500).json({message:error.message})
    }
})

app.get("/api/people/:id",async(req,res)=>{
    try{
        const { id } = req.params;
        const person = await People.findById(id);
        res.status(200).json(person);
    }catch(error){
        res.status(500).json({message:error.message})
    }
})
app.put("/api/people/:id",async(req,res)=>{
    try{
        const {id} = req.params;
        const person = await People.findByIdAndUpdate(id,req.body);
        if (!person){
            res.status(404).json({message:"Person with specified ID not found"})
        }
        const updatedPerson = await People.findById(id);
        res.status(200).json(updatedPerson)
    }catch(error){
        res.status(500).json({message:error.message})
    }
})

app.delete("/api/people/:id",async(req,res)=>{
    try{
        const {id}= req.params;
        const person = await People.findByIdAndDelete(id);
        if (!person){
            res.status(404).json("Person with specified ID did not exist");
        }
        res.status(200).json({message:"Product successfully deleted"})
    }catch(error){
        res.status(500).json({message:error.message})
    }
})