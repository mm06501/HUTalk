import React, { useState } from 'react';
import './App.css';

const ChatPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const chats = [
    { id: 1, name: 'Ahsan Azeemi', lastMessage: "Okay bhai." },
    { id: 2, name: 'Maaz Shaheen', lastMessage: "Hey, I'll be late can you mark my attendance?"},
    { id: 3, name: 'Shahzar', lastMessage: "Oye aaj Class activity to nahi hogi?"}
  ];

  const conversations = [
    { id: 1, sender: 'Ahsan Azeemi', message: 'Bhai attendance horahi jaldi aaja!' },
    { id: 2, sender: 'You', message: 'Okay bhai bas 2 min main araha.' },
    // More conversation data
  ];

  return (
    <div className="chat-container">
      <div className="chat-sidebar">
        <input
          type="text"
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="chat-search-bar"
        />
        <div className="chat-list">
          {chats.map(chat => (
            <div key={chat.id} className="chat-list-item">
              <h4>{chat.name}</h4>
              <p>{chat.lastMessage}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="chat-main">
        <div className="chat-header">
          <h2>Conversation with Ahsan Azeemi</h2>
        </div>
        <div className="chat-messages">
          {conversations.map(convo => (
            <div key={convo.id} className="message-item">
              <strong>{convo.sender}</strong>: {convo.message}
            </div>
          ))}
        </div>
        <div className="chat-input-container">
          <input type="text" placeholder="Type a message..." className="chat-input" />
          <button className="send-button">Send</button>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
