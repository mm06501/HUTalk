import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';  // Optional: if you have a global CSS file
import App from './App';  // Import the main App component

// Render the App component and attach it to the root div in the HTML
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')  // 'root' refers to the HTML element where the React app will be inserted
);
