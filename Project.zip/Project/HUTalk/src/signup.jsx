import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation
import './App.css';

const SignUpPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSignUp = (e) => {
    e.preventDefault();
    // Logic for signup (if needed)
  };

  return (
    <div className="signup-container">
      <h2>Create your HUTalk account</h2>
      <form onSubmit={handleSignUp} className="signup-form">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          className="input-field"
        />
        {/* Using Link for navigation on button click */}
        <Link to="/login">
          <button type="submit" className="signup-button">Sign Up</button>
        </Link>
      </form>
      <p>Already have an account? <Link to="/login" style={{ color: '#fbc02d' }}>Sign In</Link></p>
    </div>
  );
};

export default SignUpPage;
