import React from 'react';
import './App.css';
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div className="home-container">
      <h1>Welcome to HUTalk</h1>
      <div className="home-buttons">
        <Link to="/login">
          <button className="home-button">Sign In</button>
        </Link>
        <Link to="/signup">
          <button className="home-button">Sign Up</button>
        </Link>
        <Link to="/crud">
        <button classname="data-button">Manage Database</button>
        </Link>
      </div>
    </div>
  );
};

export default HomePage;
