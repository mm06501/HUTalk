import React from 'react'

const crud = () => {
  return (
    <div>
      <h1>Database Management Page</h1>
      <button>Get All People</button>
      <button>Get A Person</button>
      <button>Add A Person</button>
      <button>Update A Person</button>
      <button>Delete A Person</button>
    </div>
  )
}

export default crud
