import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation
import './App.css';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    // Logic for login (if needed)
  };

  return (
    <div className="login-container">
      <h2>Sign In to HUTalk</h2>
      <form onSubmit={handleLogin} className="login-form">
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="input-field"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="input-field"
        />
        {/* Using Link for navigation on button click */}
        <Link to="/chat">
          <button type="submit" className="submit-button">Sign In</button>
        </Link>
      </form>
      <p>Don't have an account? <Link to="/signup" style={{ color: '#fbc02d' }}>Sign Up</Link></p>
    </div>
  );
};

export default LoginPage;
